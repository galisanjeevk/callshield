package app.callshield.data

import android.content.Context
import android.content.SharedPreferences
import android.telephony.TelephonyManager
import app.callshield.core.PhoneNumbers
import app.callshield.core.RuleSettings
import app.callshield.core.UnknownMode
import app.callshield.core.Verdict
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

data class LogEntry(val number: String, val time: Long, val verdict: Verdict, val reason: String)

/** All app data lives in private app storage on the phone. Nothing is ever uploaded. */
class Store(context: Context) {

    private val app = context.applicationContext
    private val prefs: SharedPreferences = app.getSharedPreferences("callshield", Context.MODE_PRIVATE)
    private val logFile = File(app.filesDir, "screened_calls.json")

    // ---------- settings ----------

    var homeCode: String
        get() = prefs.getString("homeCode", null) ?: detectHomeCode()
        set(v) = prefs.edit().putString("homeCode", v.filter { it.isDigit() }.ifEmpty { "91" }).apply()

    var blockHidden by bool("blockHidden", true)
    var blockTelemarketers by bool("blockTelemarketers", true)
    var trustOfficialSeries by bool("trustOfficialSeries", true)
    var blockRiskyCountries by bool("blockRiskyCountries", true)
    var blockInternational by bool("blockInternational", false)
    var blockSpoofed by bool("blockSpoofed", true)
    var letRepeatCallersThrough by bool("repeatCallers", true)
    var notifyOnBlock by bool("notifyOnBlock", true)
    var logAllowedUnknown by bool("logAllowedUnknown", true)

    var unknownMode: UnknownMode
        get() = runCatching { UnknownMode.valueOf(prefs.getString("unknownMode", "ALLOW")!!) }.getOrDefault(UnknownMode.ALLOW)
        set(v) = prefs.edit().putString("unknownMode", v.name).apply()

    var riskyCodes: List<String>
        get() = (prefs.getString("riskyCodes", null) ?: RuleSettings.DEFAULT_RISKY_CODES.joinToString(","))
            .split(',', ' ').map { it.filter(Char::isDigit) }.filter { it.isNotEmpty() }
        set(v) = prefs.edit().putString("riskyCodes", v.joinToString(",")).apply()

    fun ruleSettings() = RuleSettings(
        homeCode = homeCode,
        blockHidden = blockHidden,
        blockTelemarketers = blockTelemarketers,
        trustOfficialSeries = trustOfficialSeries,
        blockRiskyCountries = blockRiskyCountries,
        riskyCountryCodes = riskyCodes,
        blockInternational = blockInternational,
        blockSpoofed = blockSpoofed,
        unknownMode = unknownMode,
        letRepeatCallersThrough = letRepeatCallersThrough,
    )

    // ---------- block / allow lists ----------

    val blockList: Set<String> get() = prefs.getStringSet("blockList", emptySet())!!.toSet()
    val allowList: Set<String> get() = prefs.getStringSet("allowList", emptySet())!!.toSet()

    /** Returns the normalised entry that was stored, or null if the input was invalid. */
    fun addToBlockList(input: String): String? = addTo("blockList", "allowList", input)
    fun addToAllowList(input: String): String? = addTo("allowList", "blockList", input)
    fun removeFromBlockList(entry: String) = removeFrom("blockList", entry)
    fun removeFromAllowList(entry: String) = removeFrom("allowList", entry)

    private fun addTo(key: String, otherKey: String, input: String): String? {
        val entry = PhoneNumbers.normalizePattern(input, homeCode)
        if (entry.isEmpty()) return null
        synchronized(LOCK) {
            val set = prefs.getStringSet(key, emptySet())!!.toMutableSet().apply { add(entry) }
            val other = prefs.getStringSet(otherKey, emptySet())!!.toMutableSet().apply { remove(entry) }
            prefs.edit().putStringSet(key, set).putStringSet(otherKey, other).apply()
        }
        return entry
    }

    private fun removeFrom(key: String, entry: String) = synchronized(LOCK) {
        val set = prefs.getStringSet(key, emptySet())!!.toMutableSet().apply { remove(entry) }
        prefs.edit().putStringSet(key, set).apply()
    }

    // ---------- screened-call log ----------

    fun log(): List<LogEntry> = synchronized(LOCK) { readLog() }

    fun addLog(e: LogEntry) = synchronized(LOCK) {
        val list = readLog().toMutableList()
        list.add(0, e)
        writeLog(list.take(MAX_LOG))
    }

    fun clearLog() = synchronized(LOCK) { logFile.delete(); Unit }

    fun recentAttempts(number: String, withinMs: Long = REPEAT_WINDOW_MS): Int {
        if (number.isEmpty()) return 0
        val since = System.currentTimeMillis() - withinMs
        return log().count { it.number == number && it.time >= since }
    }

    var totalBlocked: Long
        get() = prefs.getLong("totalBlocked", 0)
        set(v) = prefs.edit().putLong("totalBlocked", v).apply()

    private fun readLog(): List<LogEntry> = runCatching {
        if (!logFile.exists()) return emptyList()
        val arr = JSONArray(logFile.readText())
        (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            LogEntry(o.getString("n"), o.getLong("t"), Verdict.valueOf(o.getString("v")), o.optString("r"))
        }
    }.getOrDefault(emptyList())

    private fun writeLog(list: List<LogEntry>) {
        val arr = JSONArray()
        list.forEach { arr.put(JSONObject().put("n", it.number).put("t", it.time).put("v", it.verdict.name).put("r", it.reason)) }
        val tmp = File(logFile.path + ".tmp")
        tmp.writeText(arr.toString())
        tmp.renameTo(logFile)
    }

    // ---------- helpers ----------

    private fun detectHomeCode(): String {
        val tm = app.getSystemService(TelephonyManager::class.java)
        val iso = (tm?.simCountryIso?.takeIf { it.isNotBlank() } ?: tm?.networkCountryIso ?: "in").lowercase()
        return COUNTRY_CODES[iso] ?: "91"
    }

    private fun bool(key: String, default: Boolean) = object : kotlin.properties.ReadWriteProperty<Any?, Boolean> {
        override fun getValue(thisRef: Any?, property: kotlin.reflect.KProperty<*>) = prefs.getBoolean(key, default)
        override fun setValue(thisRef: Any?, property: kotlin.reflect.KProperty<*>, value: Boolean) {
            prefs.edit().putBoolean(key, value).apply()
        }
    }

    companion object {
        private val LOCK = Any()
        const val MAX_LOG = 400
        const val REPEAT_WINDOW_MS = 5 * 60 * 1000L

        private val COUNTRY_CODES = mapOf(
            "in" to "91", "us" to "1", "ca" to "1", "gb" to "44", "ae" to "971", "sa" to "966", "qa" to "974",
            "kw" to "965", "om" to "968", "bh" to "973", "sg" to "65", "my" to "60", "au" to "61", "nz" to "64",
            "de" to "49", "fr" to "33", "it" to "39", "es" to "34", "nl" to "31", "ie" to "353", "np" to "977",
            "bd" to "880", "lk" to "94", "pk" to "92", "id" to "62", "ph" to "63", "za" to "27", "ng" to "234",
            "ke" to "254", "br" to "55", "mx" to "52", "jp" to "81", "kr" to "82",
        )
    }
}
