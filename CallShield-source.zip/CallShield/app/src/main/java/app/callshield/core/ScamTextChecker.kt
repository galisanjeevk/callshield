package app.callshield.core

/**
 * Offline scam-message checker. Paste an SMS / WhatsApp / email text and it lists red flags.
 * Rules are based on common fraud patterns in India (KYC, digital arrest, parcel, power cut,
 * task jobs, investment groups, UPI collect, OTP requests). Nothing leaves the phone.
 */
object ScamTextChecker {

    data class Flag(val title: String, val weight: Int)
    data class Result(val score: Int, val level: Level, val flags: List<Flag>)
    enum class Level { LOW, MEDIUM, HIGH }

    private class Rule(val title: String, val weight: Int, val words: List<String>)

    private val rules = listOf(
        Rule("Asks for OTP, PIN, CVV or password — no genuine bank or company ever does", 5,
            listOf("otp", "one time password", "cvv", "upi pin", "atm pin", "mpin", "password", "share the code", "verification code")),
        Rule("'Digital arrest' / police / CBI / ED threat — no agency arrests anyone over a video call", 6,
            listOf("digital arrest", "cbi", "enforcement directorate", " ed officer", "narcotics", "money laundering", "arrest warrant",
                "cyber police", "mumbai police", "customs officer", "fir has been", "drugs found", "video call statement")),
        Rule("Threatens to block your account, SIM, gas or electricity", 4,
            listOf("will be blocked", "will be suspended", "will be disconnected", "electricity will be", "power will be cut",
                "sim will be", "account blocked", "account suspended", "kyc expired", "kyc update", "update your kyc", "pan card blocked",
                "band ho jayega", "disconnect tonight", "last warning", "final notice")),
        Rule("Creates urgency to make you act without thinking", 2,
            listOf("urgent", "immediately", "within 24 hours", "today only", "act now", "turant","expire today", "last date today")),
        Rule("Prize, lottery, cashback or refund you never asked for", 4,
            listOf("lottery", "you have won", "you won", "prize", "lucky draw", "cashback of", "refund of", "kbc", "reward points expire",
                "claim your", "inaam", "gift voucher")),
        Rule("Work-from-home / like-and-earn task job", 4,
            listOf("part time job", "part-time job", "work from home", "daily income", "earn rs", "earn ₹", "like youtube", "rate hotels",
                "task based", "prepaid task", "telegram task", "per day salary")),
        Rule("Too-good investment returns / trading tip groups", 4,
            listOf("guaranteed return", "double your money", "ipo allotment", "stock tips", "trading group", "vip group", "200% profit",
                "daily profit", "crypto investment", "institutional account")),
        Rule("Parcel / courier / customs problem", 3,
            listOf("parcel", "courier", "fedex", "dhl", "india post", "delivery failed", "customs duty", "address incomplete", "package held")),
        Rule("Asks you to pay, scan a QR or approve a UPI request", 4,
            listOf("scan the qr", "scan this qr", "collect request", "approve the request", "pay rs", "pay ₹", "processing fee",
                "registration fee", "transfer the amount", "send money", "security deposit")),
        Rule("Asks you to install an app or APK (screen-sharing / remote control)", 5,
            listOf(".apk", "anydesk", "teamviewer", "quicksupport", "rustdesk", "install this app", "download the app", "screen share")),
        Rule("Impersonates a bank, government body, telecom or power company", 2,
            listOf("dear customer", "sbi", "hdfc", "icici", "axis bank", "rbi", "trai", "dot ", "income tax", "aadhaar", "electricity board",
                "bses", "msedcl", "tneb", "jio", "airtel", "vodafone", "npci")),
        Rule("Sextortion / blackmail language", 6,
            listOf("video will be leaked", "your private video", "nude", "will viral", "send to your contacts")),
    )

    private val urlRegex = Regex("""(https?://\S+|www\.\S+|\b[a-z0-9-]+\.(xyz|top|click|link|live|online|site|info|icu|shop|buzz|cc|in)/\S*)""",
        RegexOption.IGNORE_CASE)
    private val shortenerRegex = Regex("""\b(bit\.ly|tinyurl\.com|t\.ly|cutt\.ly|is\.gd|rb\.gy|shorturl\.at|t\.me|wa\.me)\b""",
        RegexOption.IGNORE_CASE)
    private val phoneRegex = Regex("""(\+?\d[\d\s-]{9,14}\d)""")

    fun check(text: String): Result {
        val t = " " + text.lowercase() + " "
        val flags = mutableListOf<Flag>()
        for (r in rules) if (r.words.any { t.contains(it) }) flags += Flag(r.title, r.weight)

        if (shortenerRegex.containsMatchIn(t)) flags += Flag("Uses a shortened or chat link that hides where it goes", 3)
        else if (urlRegex.containsMatchIn(t)) flags += Flag("Contains a link — open bank or govt sites by typing the address yourself", 2)
        if (phoneRegex.containsMatchIn(text) && flags.isNotEmpty()) flags += Flag("Asks you to call or WhatsApp a personal number", 1)

        val score = flags.sumOf { it.weight }
        val level = when {
            score >= 7 -> Level.HIGH
            score >= 3 -> Level.MEDIUM
            else -> Level.LOW
        }
        return Result(score, level, flags.sortedByDescending { it.weight })
    }
}
