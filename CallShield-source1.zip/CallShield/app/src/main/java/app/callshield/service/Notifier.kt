package app.callshield.service

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import app.callshield.R
import app.callshield.core.PhoneNumbers
import app.callshield.data.Store
import app.callshield.ui.MainActivity

object Notifier {
    private const val CHANNEL = "blocked_calls"
    const val ACTION_NOT_SPAM = "app.callshield.NOT_SPAM"
    const val EXTRA_NUMBER = "number"
    const val EXTRA_NOTIF_ID = "notif_id"

    fun ensureChannel(ctx: Context) {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        if (nm.getNotificationChannel(CHANNEL) == null) {
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL, "Blocked calls", NotificationManager.IMPORTANCE_LOW).apply {
                    description = "A quiet note each time a spam call is blocked"
                    setShowBadge(false)
                }
            )
        }
    }

    fun blocked(ctx: Context, number: String, reason: String) {
        if (Build.VERSION.SDK_INT >= 33 &&
            ctx.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) return
        ensureChannel(ctx)
        val id = (System.currentTimeMillis() % Int.MAX_VALUE).toInt()
        val shown = if (number.isEmpty()) "Hidden number" else PhoneNumbers.pretty(number, Store(ctx).homeCode)

        val open = PendingIntent.getActivity(
            ctx, 0, Intent(ctx, MainActivity::class.java).putExtra(MainActivity.EXTRA_TAB, MainActivity.TAB_LOG),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val builder = Notification.Builder(ctx, CHANNEL)
            .setSmallIcon(R.drawable.ic_shield)
            .setContentTitle("Blocked $shown")
            .setContentText(reason)
            .setContentIntent(open)
            .setAutoCancel(true)
            .setCategory(Notification.CATEGORY_STATUS)

        if (number.isNotEmpty()) {
            val notSpam = PendingIntent.getBroadcast(
                ctx, id,
                Intent(ctx, NotSpamReceiver::class.java).setAction(ACTION_NOT_SPAM)
                    .putExtra(EXTRA_NUMBER, number).putExtra(EXTRA_NOTIF_ID, id),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            val lookup = PendingIntent.getActivity(
                ctx, id,
                Intent(ctx, MainActivity::class.java)
                    .putExtra(MainActivity.EXTRA_TAB, MainActivity.TAB_LOG)
                    .putExtra(MainActivity.EXTRA_LOOKUP, number),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            builder.addAction(Notification.Action.Builder(null, "Who is this?", lookup).build())
            builder.addAction(Notification.Action.Builder(null, "Not spam", notSpam).build())
        }
        ctx.getSystemService(NotificationManager::class.java).notify(id, builder.build())
    }
}

class NotSpamReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Notifier.ACTION_NOT_SPAM) return
        val number = intent.getStringExtra(Notifier.EXTRA_NUMBER) ?: return
        Store(context).addToAllowList(number)
        context.getSystemService(NotificationManager::class.java).cancel(intent.getIntExtra(Notifier.EXTRA_NOTIF_ID, 0))
    }
}
