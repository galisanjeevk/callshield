# CallShield 🛡

A private spam & scam call blocker for Android. No ads, no trackers, no account, **no internet permission**.
Every decision is made on your phone in milliseconds.

## What it does

| Feature | How it works |
|---|---|
| Blocks spam before it rings | Uses Android's official call-screening role (Android 10+) |
| Telemarketers (India) | Blocks the **140-series** promotional numbers |
| Genuine bank / govt calls (India) | Always lets **1600 / 1601-series** numbers through. These are reserved for banks, insurers, government and regulated service calls |
| Scam country codes | Blocks **+92** by default (named in DoT advisories). You can add more codes |
| Hidden / private numbers | Blocked by default |
| Spoofed caller IDs | Blocked when the network says the caller ID failed verification (Android 11+) |
| Unknown callers | Choose: ring, **silence** (still in call log) or block. Contacts always ring |
| Repeat-caller safety | If an unknown number calls twice within 5 minutes it rings, in case it's an emergency |
| Your own block/allow lists | Exact numbers or wildcards: `+92*`, `140*`, `+9122*` |
| One-tap block after a call | The Calls tab lists blocked, silenced and unknown calls with Block / Allow / Report buttons |
| "Not spam" from the notification | One tap adds the number to your allow list |
| Scam message checker | Paste or **share** an SMS/WhatsApp message to CallShield. It flags KYC, "digital arrest", parcel, power cut, task-job, investment, OTP and APK scams, all offline |
| Report & help | Shortcuts to Sanchar Saathi (Chakshu), cybercrime.gov.in and the 1930 helpline |

The APK is well under 1 MB. The only dependency is the Kotlin standard library.

## Why it's different from Truecaller

* **Nothing is uploaded.** Truecaller works by collecting phone numbers from its users' contacts. CallShield reads your contacts only to recognise who's calling, and it has no internet permission, so it can't send them anywhere.
* **No ads, no premium upsell, no chat or payment features.**
* **The trade-off:** CallShield can't show a caller's *name* for unknown numbers, because that needs a crowd-sourced database. It blocks by rules (number series, country codes, hidden or spoofed IDs, unknown callers) and by your own lists.

## Get the APK (no computer needed)

1. Create a free GitHub account and a new repository.
2. Upload all files from this folder. On a phone, use **Add file → Upload files** on github.com.
3. Open the **Actions** tab. The "Build APK" workflow runs on its own (about 4 minutes).
4. Open the finished run, download **CallShield-apk**, unzip it and tap `CallShield.apk` to install.
   Android will ask you to allow installs from your browser or file manager.

### Or build on a computer
Install Android Studio, open this folder and press Run, or run `./gradlew assembleRelease`.

### Stable signing (optional)
Without your own key, each CI build is signed with a new throwaway debug key, so you must uninstall before installing a newer build.
For seamless updates, create a keystore and set the `CALLSHIELD_KEYSTORE`, `CALLSHIELD_KEYSTORE_PASSWORD`,
`CALLSHIELD_KEY_ALIAS` and `CALLSHIELD_KEY_PASSWORD` environment variables when building.

## First-run setup on the phone
1. Open CallShield and tap **Turn on protection**. Choose CallShield as your *Caller ID & spam app*.
2. Allow **Contacts** so your contacts are never blocked, and allow **Notifications**.
3. On Xiaomi, Oppo, Vivo and Realme phones, also set Battery → *No restrictions* for CallShield.

## Project layout
```
app/src/main/java/app/callshield/
  core/      CallRules (decision engine), PhoneNumbers, ScamTextChecker   ← pure Kotlin, unit tested
  data/      Store: settings, lists, call log (private app storage)
  service/   ShieldScreeningService (Android CallScreeningService), notifications
  ui/        MainActivity: Shield · Calls · Lists · Scam check
app/src/test/  CallRulesTest
```
