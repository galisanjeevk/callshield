package app.callshield.service

import android.Manifest
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.ContactsContract
import android.telecom.Call
import android.telecom.CallScreeningService
import android.telecom.Connection
import android.telecom.TelecomManager
import app.callshield.core.CallRules
import app.callshield.core.IncomingCall
import app.callshield.core.PhoneNumbers
import app.callshield.core.UnknownMode
import app.callshield.core.Verdict
import app.callshield.data.LogEntry
import app.callshield.data.Store

/**
 * Android asks this service about every incoming call (once the user grants the
 * "Caller ID & spam" role). We answer in milliseconds, entirely on-device.
 */
class ShieldScreeningService : CallScreeningService() {

    override fun onScreenCall(details: Call.Details) {
        if (details.callDirection != Call.Details.DIRECTION_INCOMING) {
            respondToCall(details, CallResponse.Builder().build())
            return
        }

        val store = Store(this)
        val decision = runCatching {
            val raw = details.handle?.schemeSpecificPart
            val hidden = raw.isNullOrBlank() || details.handlePresentation != TelecomManager.PRESENTATION_ALLOWED
            val number = PhoneNumbers.normalize(raw, store.homeCode)
            val verificationFailed = Build.VERSION.SDK_INT >= Build.VERSION_CODES.R &&
                details.callerNumberVerificationStatus == Connection.VERIFICATION_STATUS_FAILED

            val call = IncomingCall(
                rawNumber = raw,
                isHidden = hidden,
                isContact = !hidden && isContact(raw!!),
                verificationFailed = verificationFailed,
                recentAttempts = store.recentAttempts(number),
            )
            // Without contacts access we can't tell friends from strangers, so never hard-block "unknown" callers.
            val settings = store.ruleSettings().let {
                if (!hasContactsPermission() && it.unknownMode == UnknownMode.BLOCK) it.copy(unknownMode = UnknownMode.SILENCE) else it
            }
            val d = CallRules.decide(call, settings, store.blockList, store.allowList)
            Triple(d, number, call.isContact)
        }.getOrNull()

        if (decision == null) { // Never break calls because of a bug: fail open.
            respondToCall(details, CallResponse.Builder().build())
            return
        }
        val (d, number, isContact) = decision

        val response = when (d.verdict) {
            Verdict.BLOCK -> CallResponse.Builder()
                .setDisallowCall(true)
                .setRejectCall(true)
                .setSkipCallLog(false)
                .setSkipNotification(true)
                .build()
            Verdict.SILENCE -> CallResponse.Builder().setSilenceCall(true).build()
            Verdict.ALLOW -> CallResponse.Builder().build()
        }
        respondToCall(details, response)

        // Bookkeeping after responding so the phone rings without delay.
        val shouldLog = d.verdict != Verdict.ALLOW || (!isContact && store.logAllowedUnknown)
        if (shouldLog) store.addLog(LogEntry(number.ifEmpty { "Hidden" }, System.currentTimeMillis(), d.verdict, d.reason))
        if (d.verdict == Verdict.BLOCK) {
            store.totalBlocked = store.totalBlocked + 1
            if (store.notifyOnBlock) Notifier.blocked(this, number, d.reason)
        }
    }

    private fun hasContactsPermission() =
        checkSelfPermission(Manifest.permission.READ_CONTACTS) == PackageManager.PERMISSION_GRANTED

    private fun isContact(raw: String): Boolean {
        if (!hasContactsPermission()) return false
        val uri = Uri.withAppendedPath(ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(raw))
        return runCatching {
            contentResolver.query(uri, arrayOf(ContactsContract.PhoneLookup._ID), null, null, null)?.use { it.count > 0 } ?: false
        }.getOrDefault(false)
    }
}
