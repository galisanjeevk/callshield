package app.callshield.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast

/**
 * "Who is this?" lookup. CallShield itself has no internet access, so it hands the number
 * to an app the user already trusts: Truecaller if installed, otherwise a web search.
 * The number is copied so it can be pasted into Truecaller's search box.
 */
object Lookup {
    private const val TRUECALLER = "com.truecaller"

    fun hasTruecaller(ctx: Context) = ctx.packageManager.getLaunchIntentForPackage(TRUECALLER) != null

    fun open(ctx: Context, number: String) {
        ctx.getSystemService(ClipboardManager::class.java)?.setPrimaryClip(ClipData.newPlainText("number", number))
        val truecaller = ctx.packageManager.getLaunchIntentForPackage(TRUECALLER)
        val intent = truecaller
            ?: Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode("\"$number\" spam OR scam")))
        try {
            ctx.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            Toast.makeText(
                ctx,
                if (truecaller != null) "Number copied. Paste it into Truecaller's search." else "Searching the web for reports on this number",
                Toast.LENGTH_LONG
            ).show()
        } catch (_: Exception) {
            Toast.makeText(ctx, "Number copied. No app found to look it up.", Toast.LENGTH_LONG).show()
        }
    }
}
