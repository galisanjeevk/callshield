package app.callshield.core

/**
 * Small, dependency-free phone number helpers.
 * Numbers are normalised to "+<country><national>" so that "098765 43210",
 * "+91 98765-43210" and "919876543210" all compare equal.
 */
object PhoneNumbers {

    /** Very short numbers (service codes like 121, 1909, 198) are kept as-is. */
    private const val SHORT_CODE_MAX = 6

    fun normalize(raw: String?, homeCode: String): String {
        if (raw.isNullOrBlank()) return ""
        val trimmed = raw.trim()
        val digits = trimmed.filter { it.isDigit() }
        if (digits.isEmpty()) return ""
        val home = homeCode.filter { it.isDigit() }.ifEmpty { "91" }

        if (trimmed.startsWith("+")) return "+$digits"
        if (digits.startsWith("00") && digits.length > 8) return "+" + digits.drop(2)
        if (digits.length <= SHORT_CODE_MAX) return digits

        val national = digits.trimStart('0')
        // Already contains the home country code (e.g. 919876543210)
        if (home == "91" && national.length == 12 && national.startsWith("91")) return "+$national"
        if (home != "91" && national.startsWith(home) && national.length > home.length + 8) return "+$national"
        return "+$home$national"
    }

    /**
     * Normalises a user-entered list entry. A trailing '*' means "starts with".
     * "140*" -> "+91140*", "+92*" -> "+92*", "9876543210" -> "+919876543210".
     */
    fun normalizePattern(raw: String, homeCode: String): String {
        val t = raw.trim()
        if (t.isEmpty()) return ""
        val wildcard = t.endsWith("*")
        val body = t.trimEnd('*').trim()
        if (body.isEmpty()) return ""
        val n = if (wildcard) {
            val digits = body.filter { it.isDigit() }
            if (digits.isEmpty()) return ""
            when {
                body.startsWith("+") -> "+$digits"
                digits.startsWith("00") -> "+" + digits.drop(2)
                else -> "+" + homeCode.filter { it.isDigit() } + digits.trimStart('0')
            }
        } else normalize(body, homeCode)
        if (n.isEmpty()) return ""
        return if (wildcard) "$n*" else n
    }

    fun matches(pattern: String, number: String): Boolean {
        if (pattern.isEmpty() || number.isEmpty()) return false
        return if (pattern.endsWith("*")) number.startsWith(pattern.dropLast(1)) else number == pattern
    }

    /** National part of a domestic number, or null if the number is international / short. */
    fun nationalPart(normalized: String, homeCode: String): String? {
        val prefix = "+" + homeCode.filter { it.isDigit() }
        return if (normalized.startsWith(prefix)) normalized.removePrefix(prefix) else null
    }

    fun isInternational(normalized: String, homeCode: String): Boolean =
        normalized.startsWith("+") && nationalPart(normalized, homeCode) == null

    /** Pretty print for display: "+91 98765 43210". */
    fun pretty(normalized: String, homeCode: String): String {
        val national = nationalPart(normalized, homeCode) ?: return normalized
        val code = homeCode.filter { it.isDigit() }
        return if (code == "91" && national.length == 10 && !national.startsWith("1"))
            "+91 ${national.substring(0, 5)} ${national.substring(5)}"
        else "+$code $national"
    }
}
