plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "app.callshield"
    compileSdk = 35

    defaultConfig {
        applicationId = "app.callshield"
        minSdk = 29          // Android 10+: system call-screening role
        targetSdk = 35
        versionCode = 1
        versionName = "1.0.0"
    }

    signingConfigs {
        // If you add a keystore (see README), release builds use it; otherwise the debug key is used.
        create("release") {
            val ks = System.getenv("CALLSHIELD_KEYSTORE")
            if (ks != null && file(ks).exists()) {
                storeFile = file(ks)
                storePassword = System.getenv("CALLSHIELD_KEYSTORE_PASSWORD")
                keyAlias = System.getenv("CALLSHIELD_KEY_ALIAS")
                keyPassword = System.getenv("CALLSHIELD_KEY_PASSWORD")
            }
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
            val rel = signingConfigs.getByName("release")
            signingConfig = if (rel.storeFile != null) rel else signingConfigs.getByName("debug")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }

    dependenciesInfo {
        includeInApk = false
        includeInBundle = false
    }
}

// No AndroidX, no Google Play Services, no analytics, no ad SDKs. Only the Kotlin standard library.
dependencies {
    testImplementation("junit:junit:4.13.2")
}
