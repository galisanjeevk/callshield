package app.callshield.ui

import android.Manifest
import android.app.Activity
import android.app.role.RoleManager
import android.content.ActivityNotFoundException
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.text.format.DateUtils
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowInsets
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import app.callshield.core.PhoneNumbers
import app.callshield.core.ScamTextChecker
import app.callshield.core.UnknownMode
import app.callshield.core.Verdict
import app.callshield.data.LogEntry
import app.callshield.data.Store
import app.callshield.service.Notifier

class MainActivity : Activity() {

    companion object {
        const val EXTRA_TAB = "tab"
        const val EXTRA_LOOKUP = "lookup"
        const val TAB_SHIELD = 0
        const val TAB_LOG = 1
        const val TAB_LISTS = 2
        const val TAB_SCAM = 3
        private const val REQ_ROLE = 10
        private const val REQ_PERMS = 11
        private const val CHAKSHU_URL = "https://sancharsaathi.gov.in/"
        private const val CYBERCRIME_URL = "https://cybercrime.gov.in/"
    }

    private lateinit var ui: Ui
    private lateinit var store: Store
    private lateinit var body: LinearLayout
    private lateinit var scroll: ScrollView
    private val tabViews = mutableListOf<TextView>()
    private var tab = TAB_SHIELD
    private var scamDraft = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ui = Ui(this)
        store = Store(this)
        Notifier.ensureChannel(this)
        window.statusBarColor = ui.page
        window.navigationBarColor = ui.surface
        if (!ui.dark) {
            @Suppress("DEPRECATION")
            window.decorView.systemUiVisibility =
                View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        }
        tab = savedInstanceState?.getInt(EXTRA_TAB) ?: TAB_SHIELD
        buildShell()
        handleIntent(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIntent(intent)
    }

    override fun onResume() {
        super.onResume()
        render()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putInt(EXTRA_TAB, tab)
    }

    private fun handleIntent(i: Intent?) {
        if (i == null) return
        if (i.action == Intent.ACTION_SEND && i.type?.startsWith("text/") == true) {
            scamDraft = i.getStringExtra(Intent.EXTRA_TEXT).orEmpty()
            tab = TAB_SCAM
        } else if (i.hasExtra(EXTRA_TAB)) {
            tab = i.getIntExtra(EXTRA_TAB, TAB_SHIELD)
        }
        i.getStringExtra(EXTRA_LOOKUP)?.let { n ->
            i.removeExtra(EXTRA_LOOKUP) // don't repeat on rotation
            Lookup.open(this, n)
        }
        render()
    }

    // ------------------------------------------------------------------ shell

    private fun buildShell() {
        val root = ui.column().apply { setBackgroundColor(ui.page) }
        val header = ui.row().apply {
            setPadding(ui.dp(20), ui.dp(16), ui.dp(20), ui.dp(4))
            addView(ui.text("🛡", 26f).apply { setPadding(0, 0, ui.dp(10), 0) })
            addView(ui.column().apply {
                addView(ui.text("CallShield", 22f, ui.fg, bold = true))
                addView(ui.text("Private spam & scam blocker · no ads · offline", 12.5f, ui.sub))
            })
        }
        body = ui.column(16)
        scroll = ScrollView(this).apply { addView(body); isFillViewport = true }
        val nav = ui.row().apply {
            setBackgroundColor(ui.surface)
            setPadding(ui.dp(6), ui.dp(6), ui.dp(6), ui.dp(6))
        }
        listOf("🛡\nShield", "📞\nCalls", "📋\nLists", "🔎\nScam check").forEachIndexed { i, label ->
            val tv = ui.text(label, 12f, ui.sub, bold = true).apply {
                gravity = Gravity.CENTER
                setPadding(0, ui.dp(8), 0, ui.dp(8))
                setOnClickListener { tab = i; scamDraftFromScreen(); render(); scroll.scrollTo(0, 0) }
            }
            tabViews += tv
            nav.addView(tv, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        }
        root.addView(header)
        root.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        root.addView(ui.divider())
        root.addView(nav)

        root.setOnApplyWindowInsetsListener { v, insets ->
            if (Build.VERSION.SDK_INT >= 30) {
                val b = insets.getInsets(WindowInsets.Type.systemBars() or WindowInsets.Type.ime())
                v.setPadding(b.left, b.top, b.right, b.bottom)
            } else {
                @Suppress("DEPRECATION")
                v.setPadding(insets.systemWindowInsetLeft, insets.systemWindowInsetTop,
                    insets.systemWindowInsetRight, insets.systemWindowInsetBottom)
            }
            insets
        }
        setContentView(root)
    }

    private var scamInput: android.widget.EditText? = null
    private fun scamDraftFromScreen() { scamInput?.let { scamDraft = it.text.toString() } }

    private fun render() {
        if (!::body.isInitialized) return
        tabViews.forEachIndexed { i, tv ->
            tv.setTextColor(if (i == tab) ui.accent else ui.sub)
            tv.background = if (i == tab) ui.rounded((ui.accent and 0x00FFFFFF) or 0x1A000000, 14) else null
        }
        body.removeAllViews()
        scamInput = null
        when (tab) {
            TAB_SHIELD -> renderShield()
            TAB_LOG -> renderLog()
            TAB_LISTS -> renderLists()
            TAB_SCAM -> renderScam()
        }
    }

    // ------------------------------------------------------------------ Shield tab

    private fun hasRole(): Boolean {
        val rm = getSystemService(RoleManager::class.java) ?: return false
        return rm.isRoleAvailable(RoleManager.ROLE_CALL_SCREENING) && rm.isRoleHeld(RoleManager.ROLE_CALL_SCREENING)
    }

    private fun granted(p: String) = checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED

    @Suppress("DEPRECATION")
    private fun requestRole() {
        val rm = getSystemService(RoleManager::class.java)
        if (rm == null || !rm.isRoleAvailable(RoleManager.ROLE_CALL_SCREENING)) {
            toast("This phone doesn't support call screening apps")
            return
        }
        startActivityForResult(rm.createRequestRoleIntent(RoleManager.ROLE_CALL_SCREENING), REQ_ROLE)
    }

    private fun requestPerms() {
        val perms = mutableListOf(Manifest.permission.READ_CONTACTS)
        if (Build.VERSION.SDK_INT >= 33) perms += Manifest.permission.POST_NOTIFICATIONS
        requestPermissions(perms.filterNot(::granted).toTypedArray(), REQ_PERMS)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_ROLE) {
            if (hasRole()) { toast("Protection is on"); if (!granted(Manifest.permission.READ_CONTACTS)) requestPerms() }
            render()
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        render()
    }

    private fun renderShield() {
        val on = hasRole()
        val contactsOk = granted(Manifest.permission.READ_CONTACTS)
        val notifOk = Build.VERSION.SDK_INT < 33 || granted(Manifest.permission.POST_NOTIFICATIONS)

        val status = ui.card().apply {
            addView(ui.text(if (on) "● Protection is ON" else "● Protection is OFF", 20f, if (on) ui.good else ui.bad, bold = true))
            addView(ui.text(
                if (on) "Every incoming call is checked on your phone before it rings. Nothing is uploaded anywhere."
                else "Give CallShield the “Caller ID & spam” role so Android lets it screen incoming calls.",
                14f, ui.sub
            ).apply { setPadding(0, ui.dp(6), 0, ui.dp(10)) })
            if (!on) addView(ui.button("Turn on protection") { requestRole() })
            if (on && (!contactsOk || !notifOk)) {
                addView(ui.text(
                    buildString {
                        if (!contactsOk) append("• Allow Contacts so friends and family are never blocked.\n")
                        if (!notifOk) append("• Allow notifications to see when a spam call is blocked.")
                    }.trim(), 13.5f, ui.warn
                ).apply { setPadding(0, 0, 0, ui.dp(10)) })
                addView(ui.button("Grant permissions", filled = false) { requestPerms() })
            }
            val week = System.currentTimeMillis() - 7 * DateUtils.DAY_IN_MILLIS
            val lastWeek = store.log().count { it.verdict == Verdict.BLOCK && it.time >= week }
            addView(ui.spacer(10))
            addView(ui.divider())
            addView(ui.row().apply {
                setPadding(0, ui.dp(12), 0, 0)
                addView(stat("${store.totalBlocked}", "blocked in total"), LinearLayout.LayoutParams(0, -2, 1f))
                addView(stat("$lastWeek", "blocked this week"), LinearLayout.LayoutParams(0, -2, 1f))
            })
        }
        body.addView(status)

        // Unknown callers
        body.addView(ui.title("Callers not in your contacts"))
        val group = RadioGroup(this).apply { orientation = RadioGroup.VERTICAL }
        listOf(
            UnknownMode.ALLOW to "Ring normally (only spam rules apply)",
            UnknownMode.SILENCE to "Silence — shows in call log, phone stays quiet",
            UnknownMode.BLOCK to "Block — only contacts can reach me",
        ).forEach { (mode, label) ->
            group.addView(RadioButton(this).apply {
                id = View.generateViewId()
                text = label; textSize = 15f; setTextColor(ui.fg)
                isChecked = store.unknownMode == mode
                setPadding(ui.dp(6), ui.dp(8), 0, ui.dp(8))
                setOnClickListener {
                    store.unknownMode = mode
                    if (mode != UnknownMode.ALLOW && !granted(Manifest.permission.READ_CONTACTS)) {
                        toast("Allow Contacts access so your contacts are never silenced")
                        requestPerms()
                    }
                }
            })
        }
        body.addView(ui.card(
            group,
            ui.divider(),
            ui.switchRow("Let repeat callers through",
                "If the same number calls twice within 5 minutes, it rings — in case it's an emergency.",
                store.letRepeatCallersThrough) { store.letRepeatCallersThrough = it },
        ))

        // Spam rules
        body.addView(ui.title("Spam & scam rules"))
        val codes = ui.input("Country codes, e.g. 92, 371", store.riskyCodes.joinToString(", "), phone = true)
        val india = store.homeCode == "91"
        body.addView(ui.card().apply {
            addView(ui.switchRow("Block hidden & private numbers", "Scammers often hide their caller ID.",
                store.blockHidden) { store.blockHidden = it })
            if (india) {
                addView(ui.divider())
                addView(ui.switchRow("Block telemarketers (140-series)",
                    "Promotional calls in India come from numbers starting with 140.",
                    store.blockTelemarketers) { store.blockTelemarketers = it })
                addView(ui.divider())
                addView(ui.switchRow("Always allow official 1600 / 1601 numbers",
                    "Banks, insurers, government and regulated businesses use these for genuine service calls.",
                    store.trustOfficialSeries) { store.trustOfficialSeries = it })
            }
            addView(ui.divider())
            addView(ui.switchRow("Block high-risk country codes",
                "DoT has warned about impersonation calls from +92 numbers. Add others below.",
                store.blockRiskyCountries) { store.blockRiskyCountries = it })
            addView(ui.row().apply {
                addView(codes, LinearLayout.LayoutParams(0, -2, 1f).apply { rightMargin = ui.dp(8) })
                addView(ui.button("Save", filled = false) {
                    store.riskyCodes = codes.text.split(',', ' ', ';').map { it.filter(Char::isDigit) }.filter { it.isNotEmpty() }
                    toast("Saved"); render()
                })
                setPadding(0, 0, 0, ui.dp(8))
            })
            addView(ui.divider())
            addView(ui.switchRow("Block all international calls", "Good if nobody abroad ever calls you.",
                store.blockInternational) { store.blockInternational = it })
            addView(ui.divider())
            addView(ui.switchRow("Block spoofed caller IDs",
                "When the network says the number failed verification (Android 11+).",
                store.blockSpoofed) { store.blockSpoofed = it })
        })

        // Other
        body.addView(ui.title("Other"))
        val home = ui.input("Home country code", store.homeCode, phone = true)
        body.addView(ui.card().apply {
            addView(ui.switchRow("Notify me when a call is blocked", null, store.notifyOnBlock) { store.notifyOnBlock = it })
            addView(ui.divider())
            addView(ui.switchRow("Show unknown callers in Calls tab",
                "So you can block a spammer in one tap after the call.", store.logAllowedUnknown) { store.logAllowedUnknown = it })
            addView(ui.divider())
            addView(ui.text("Home country code", 15f).apply { setPadding(0, ui.dp(10), 0, ui.dp(6)) })
            addView(ui.row().apply {
                addView(ui.text("+", 18f, ui.sub).apply { setPadding(0, 0, ui.dp(6), 0) })
                addView(home, LinearLayout.LayoutParams(0, -2, 1f).apply { rightMargin = ui.dp(8) })
                addView(ui.button("Save", filled = false) { store.homeCode = home.text.toString(); toast("Saved"); render() })
            })
        })

        body.addView(ui.text(
            "🔒 CallShield has no internet permission, no ads, no analytics and no account. " +
                "Your contacts and call history never leave this phone.",
            12.5f, ui.sub
        ).apply { setPadding(ui.dp(4), ui.dp(16), ui.dp(4), ui.dp(24)) })
    }

    private fun stat(n: String, label: String) = ui.column().apply {
        addView(ui.text(n, 22f, ui.fg, bold = true))
        addView(ui.text(label, 12.5f, ui.sub))
    }

    // ------------------------------------------------------------------ Calls tab

    private fun renderLog() {
        val log = store.log()
        val header = ui.row().apply {
            addView(ui.text("Recent screened calls", 17f, ui.fg, bold = true), LinearLayout.LayoutParams(0, -2, 1f))
            if (log.isNotEmpty()) addView(ui.button("Clear", filled = false) { store.clearLog(); render() })
            setPadding(ui.dp(4), 0, 0, ui.dp(10))
        }
        body.addView(header)
        if (log.isEmpty()) {
            body.addView(ui.card(
                ui.text("Nothing here yet", 16f, ui.fg, bold = true),
                ui.text("Blocked, silenced and unknown calls will show up here so you can block or allow them in one tap.",
                    14f, ui.sub).apply { setPadding(0, ui.dp(6), 0, 0) }
            ))
            return
        }
        val blocked = store.blockList
        val allowed = store.allowList
        log.forEach { body.addView(logRow(it, it.number in blocked, it.number in allowed)) }
    }

    private fun logRow(e: LogEntry, inBlock: Boolean, inAllow: Boolean): View {
        val hidden = !e.number.startsWith("+") && e.number.none { it.isDigit() }
        val shown = if (hidden) "Hidden number" else PhoneNumbers.pretty(e.number, store.homeCode)
        val (label, color) = when (e.verdict) {
            Verdict.BLOCK -> "BLOCKED" to ui.bad
            Verdict.SILENCE -> "SILENCED" to ui.warn
            Verdict.ALLOW -> "RANG" to ui.good
        }
        return ui.card().apply {
            addView(ui.row().apply {
                addView(ui.text(shown, 16.5f, ui.fg, bold = true), LinearLayout.LayoutParams(0, -2, 1f))
                addView(ui.chip(label, color))
            })
            addView(ui.text(
                "${DateUtils.getRelativeTimeSpanString(e.time, System.currentTimeMillis(), DateUtils.MINUTE_IN_MILLIS)} · ${e.reason}",
                13f, ui.sub
            ).apply { setPadding(0, ui.dp(4), 0, ui.dp(10)) })
            if (!hidden) addView(ui.row().apply {
                if (!inBlock) addView(ui.button("Block", color = ui.bad) {
                    store.addToBlockList(e.number); toast("Blocked $shown"); render()
                }, ui.wrapLp())
                if (!inAllow) addView(ui.button("Allow", filled = false, color = ui.good) {
                    store.addToAllowList(e.number); toast("$shown will always ring"); render()
                }, ui.wrapLp())
                addView(ui.button("Report", filled = false) { report(e.number) }, ui.wrapLp(0))
            })
            if (!hidden) addView(ui.button(
                if (Lookup.hasTruecaller(this@MainActivity)) "🔍 Look up in Truecaller" else "🔍 Look up on the web",
                filled = false, color = ui.sub
            ) { Lookup.open(this@MainActivity, e.number) }.apply {
                layoutParams = LinearLayout.LayoutParams(-2, -2).apply { topMargin = ui.dp(8) }
            })
        }
    }

    private fun report(number: String) {
        copy(number)
        toast("Number copied. On Sanchar Saathi, choose “Chakshu – Report suspected fraud communication”.")
        open(CHAKSHU_URL)
    }

    // ------------------------------------------------------------------ Lists tab

    private fun renderLists() {
        val input = ui.input("Number or pattern, e.g. 98765 43210 or +92*", phone = false)
        body.addView(ui.card().apply {
            addView(ui.text("Add a number", 17f, ui.fg, bold = true))
            addView(ui.text("End with * to match everything that starts with it: “+92*” blocks all of Pakistan, " +
                "“140*” all telemarketers, “+9122*” all Mumbai landlines.", 13f, ui.sub).apply {
                setPadding(0, ui.dp(4), 0, ui.dp(10))
            })
            addView(input)
            addView(ui.row().apply {
                setPadding(0, ui.dp(10), 0, 0)
                addView(ui.button("Block", color = ui.bad) {
                    val n = store.addToBlockList(input.text.toString())
                    if (n == null) toast("Enter a valid number") else { toast("Blocked $n"); render() }
                }, ui.wrapLp())
                addView(ui.button("Always allow", filled = false, color = ui.good) {
                    val n = store.addToAllowList(input.text.toString())
                    if (n == null) toast("Enter a valid number") else { toast("Allowed $n"); render() }
                }, ui.wrapLp(0))
            })
        })

        listSection("Blocked", store.blockList.sorted(), ui.bad) { store.removeFromBlockList(it); render() }
        listSection("Always allowed", store.allowList.sorted(), ui.good) { store.removeFromAllowList(it); render() }
    }

    private fun listSection(name: String, items: List<String>, color: Int, remove: (String) -> Unit) {
        body.addView(ui.title("$name (${items.size})"))
        if (items.isEmpty()) {
            body.addView(ui.text("Empty", 14f, ui.sub).apply { setPadding(ui.dp(4), 0, 0, ui.dp(8)) })
            return
        }
        body.addView(ui.card().apply {
            items.forEachIndexed { i, entry ->
                if (i > 0) addView(ui.divider())
                addView(ui.row().apply {
                    setPadding(0, ui.dp(6), 0, ui.dp(6))
                    val shown = if (entry.endsWith("*")) "$entry  (starts with)" else PhoneNumbers.pretty(entry, store.homeCode)
                    addView(ui.text(shown, 15.5f, ui.fg), LinearLayout.LayoutParams(0, -2, 1f))
                    addView(ui.text("Remove", 13.5f, color, bold = true).apply {
                        setPadding(ui.dp(12), ui.dp(8), ui.dp(4), ui.dp(8))
                        setOnClickListener { remove(entry) }
                    })
                })
            }
        })
    }

    // ------------------------------------------------------------------ Scam check tab

    private fun renderScam() {
        val input = ui.input("Paste a suspicious SMS, WhatsApp or email message here…", scamDraft, multiline = true)
        scamInput = input
        val result = ui.column()
        body.addView(ui.card().apply {
            addView(ui.text("Is this message a scam?", 17f, ui.fg, bold = true))
            addView(ui.text("Checked on your phone. Tip: in Messages or WhatsApp, long-press a message → Share → CallShield.",
                13f, ui.sub).apply { setPadding(0, ui.dp(4), 0, ui.dp(10)) })
            addView(input)
            addView(ui.row().apply {
                setPadding(0, ui.dp(10), 0, 0)
                addView(ui.button("Check message") {
                    scamDraft = input.text.toString()
                    showScamResult(result, scamDraft)
                }, ui.wrapLp())
                addView(ui.button("Clear", filled = false) { scamDraft = ""; input.setText(""); result.removeAllViews() }, ui.wrapLp(0))
            })
        })
        body.addView(result)
        if (scamDraft.isNotBlank()) showScamResult(result, scamDraft)

        body.addView(ui.title("Got a scam call or message?"))
        body.addView(ui.card().apply {
            addView(ui.text("Report it so the number gets shut down for everyone:", 14f, ui.fg))
            addView(ui.spacer(10))
            addView(ui.button("Report on Sanchar Saathi (Chakshu)") { open(CHAKSHU_URL) })
            addView(ui.spacer(8))
            addView(ui.text("Already lost money? Act fast — the first hour matters.", 14f, ui.fg).apply {
                setPadding(0, ui.dp(8), 0, ui.dp(8))
            })
            addView(ui.row().apply {
                addView(ui.button("Call 1930", color = ui.bad) { dial("1930") }, ui.wrapLp())
                addView(ui.button("cybercrime.gov.in", filled = false) { open(CYBERCRIME_URL) }, ui.wrapLp(0))
            })
        })

        body.addView(ui.title("Golden rules"))
        body.addView(ui.card(ui.text(
            "• No bank, police, CBI, TRAI or courier will ever ask for an OTP, PIN or a payment over the phone.\n" +
                "• “Digital arrest” does not exist. Real police don't question you on video calls.\n" +
                "• You never need to enter your UPI PIN to receive money.\n" +
                "• Never install apps (AnyDesk, TeamViewer, .apk files) because a caller asked you to.\n" +
                "• Hang up and call back on the number printed on your card or the official website.\n" +
                "• In India, genuine bank and government service calls are moving to 1600-series numbers.",
            14f, ui.fg
        )))
        body.addView(ui.spacer(24))
    }

    private fun showScamResult(container: LinearLayout, text: String) {
        container.removeAllViews()
        if (text.isBlank()) return
        val r = ScamTextChecker.check(text)
        val (headline, color) = when (r.level) {
            ScamTextChecker.Level.HIGH -> "Very likely a SCAM" to ui.bad
            ScamTextChecker.Level.MEDIUM -> "Suspicious — be careful" to ui.warn
            ScamTextChecker.Level.LOW -> "No common scam signs found" to ui.good
        }
        container.addView(ui.card().apply {
            background = ui.rounded(ui.surface, 18, color)
            addView(ui.text(headline, 18f, color, bold = true))
            if (r.flags.isEmpty()) {
                addView(ui.text("That doesn't guarantee it's safe. Never share OTPs or PINs, and verify through official channels.",
                    14f, ui.sub).apply { setPadding(0, ui.dp(6), 0, 0) })
            } else {
                addView(ui.text("Red flags found:", 14f, ui.sub).apply { setPadding(0, ui.dp(8), 0, ui.dp(4)) })
                r.flags.forEach { addView(ui.text("⚠ ${it.title}", 14.5f, ui.fg).apply { setPadding(0, ui.dp(4), 0, ui.dp(4)) }) }
            }
        })
    }

    // ------------------------------------------------------------------ helpers

    private fun open(url: String) = try {
        startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
    } catch (_: ActivityNotFoundException) { toast("No browser found") }

    private fun dial(n: String) = try {
        startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:$n")))
    } catch (_: ActivityNotFoundException) { toast("No phone app found") }

    private fun copy(s: String) {
        getSystemService(ClipboardManager::class.java)?.setPrimaryClip(ClipData.newPlainText("number", s))
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

}
