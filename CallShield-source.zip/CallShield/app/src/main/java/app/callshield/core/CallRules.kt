package app.callshield.core

enum class Verdict { ALLOW, SILENCE, BLOCK }

enum class UnknownMode { ALLOW, SILENCE, BLOCK }

data class Decision(val verdict: Verdict, val reason: String)

data class RuleSettings(
    val homeCode: String = "91",
    val blockHidden: Boolean = true,
    val blockTelemarketers: Boolean = true,      // India: 140-series promotional numbers
    val trustOfficialSeries: Boolean = true,     // India: 1600 / 1601 regulated service numbers
    val blockRiskyCountries: Boolean = true,
    val riskyCountryCodes: List<String> = DEFAULT_RISKY_CODES,
    val blockInternational: Boolean = false,
    val blockSpoofed: Boolean = true,
    val unknownMode: UnknownMode = UnknownMode.ALLOW,
    val letRepeatCallersThrough: Boolean = true,
) {
    companion object {
        /** Pakistan (+92) is named in DoT advisories about impersonation calls. Users can edit this list. */
        val DEFAULT_RISKY_CODES = listOf("92")
    }
}

data class IncomingCall(
    /** Raw number as delivered by the system; null/blank for hidden callers. */
    val rawNumber: String?,
    val isHidden: Boolean,
    val isContact: Boolean,
    /** The network reported that caller-ID verification failed (spoofed number). */
    val verificationFailed: Boolean = false,
    /** How many times this number was screened in the last few minutes (from our own log). */
    val recentAttempts: Int = 0,
)

/**
 * Pure decision engine — no Android APIs, so it is fully unit-testable.
 * Order matters: your own allow list and contacts always win, your block list beats everything else.
 */
object CallRules {

    fun decide(
        call: IncomingCall,
        s: RuleSettings,
        blockList: Collection<String>,
        allowList: Collection<String>,
    ): Decision {
        val number = PhoneNumbers.normalize(call.rawNumber, s.homeCode)

        if (call.isHidden || number.isEmpty()) {
            return if (s.blockHidden) Decision(Verdict.BLOCK, "Hidden / private number")
            else Decision(Verdict.ALLOW, "Hidden number (allowed by settings)")
        }

        allowList.firstOrNull { PhoneNumbers.matches(it, number) }?.let {
            return Decision(Verdict.ALLOW, "On your allow list")
        }
        if (call.isContact) return Decision(Verdict.ALLOW, "In your contacts")

        blockList.firstOrNull { PhoneNumbers.matches(it, number) }?.let {
            return Decision(Verdict.BLOCK, if (it.endsWith("*")) "Matches blocked pattern ${it}" else "On your block list")
        }

        if (s.blockSpoofed && call.verificationFailed) {
            return Decision(Verdict.BLOCK, "Caller ID failed network verification (likely spoofed)")
        }

        val national = PhoneNumbers.nationalPart(number, s.homeCode)
        val india = s.homeCode.filter { it.isDigit() } == "91"

        if (india && national != null) {
            if (s.trustOfficialSeries && (national.startsWith("1600") || national.startsWith("1601"))) {
                return Decision(Verdict.ALLOW, "Official 1600/1601 service number (bank, govt or regulated business)")
            }
            if (s.blockTelemarketers && national.startsWith("140")) {
                return Decision(Verdict.BLOCK, "Telemarketing number (140 series)")
            }
        }

        if (PhoneNumbers.isInternational(number, s.homeCode)) {
            if (s.blockRiskyCountries) {
                s.riskyCountryCodes
                    .map { it.filter { c -> c.isDigit() } }
                    .firstOrNull { it.isNotEmpty() && number.startsWith("+$it") }
                    ?.let { return Decision(Verdict.BLOCK, "High-risk country code +$it") }
            }
            if (s.blockInternational) return Decision(Verdict.BLOCK, "International call")
        }

        if (s.unknownMode != UnknownMode.ALLOW) {
            if (s.letRepeatCallersThrough && call.recentAttempts >= 1) {
                return Decision(Verdict.ALLOW, "Called again within minutes — let through in case it's urgent")
            }
            return if (s.unknownMode == UnknownMode.BLOCK) Decision(Verdict.BLOCK, "Unknown caller")
            else Decision(Verdict.SILENCE, "Unknown caller (silenced)")
        }

        return Decision(Verdict.ALLOW, "Unknown number")
    }
}
