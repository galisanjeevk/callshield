package app.callshield.core

import org.junit.Assert.assertEquals
import org.junit.Test

class CallRulesTest {

    private val s = RuleSettings()
    private fun decide(
        raw: String?, settings: RuleSettings = s, contact: Boolean = false, hidden: Boolean = false,
        block: List<String> = emptyList(), allow: List<String> = emptyList(), recent: Int = 0, spoofed: Boolean = false,
    ) = CallRules.decide(IncomingCall(raw, hidden, contact, spoofed, recent), settings, block, allow).verdict

    @Test fun normalizesIndianFormats() {
        val want = "+919876543210"
        listOf("9876543210", "09876543210", "+91 98765-43210", "919876543210", "0091 98765 43210")
            .forEach { assertEquals(it, want, PhoneNumbers.normalize(it, "91")) }
        assertEquals("1909", PhoneNumbers.normalize("1909", "91"))
        assertEquals("+923001234567", PhoneNumbers.normalize("+92 300 1234567", "91"))
    }

    @Test fun patterns() {
        assertEquals("+91140*", PhoneNumbers.normalizePattern("140*", "91"))
        assertEquals("+92*", PhoneNumbers.normalizePattern("+92*", "91"))
        assertEquals("+919876543210", PhoneNumbers.normalizePattern("98765 43210", "91"))
        assertEquals(true, PhoneNumbers.matches("+92*", "+923001234567"))
        assertEquals(false, PhoneNumbers.matches("+92*", "+919876543210"))
    }

    @Test fun contactsAndAllowListAlwaysRing() {
        assertEquals(Verdict.ALLOW, decide("+923001234567", contact = true))
        assertEquals(Verdict.ALLOW, decide("1401234567", allow = listOf("+911401234567")))
        assertEquals(Verdict.ALLOW, decide("9876543210", s.copy(unknownMode = UnknownMode.BLOCK), contact = true))
    }

    @Test fun blockListBeatsEverythingButContacts() {
        assertEquals(Verdict.BLOCK, decide("9876543210", block = listOf("+919876543210")))
        assertEquals(Verdict.BLOCK, decide("9876543210", block = listOf("+9198765*")))
        assertEquals(Verdict.BLOCK, decide("1600123456", block = listOf("+911600123456")))
    }

    @Test fun indiaSpecificRules() {
        assertEquals(Verdict.BLOCK, decide("1401234567"))
        assertEquals(Verdict.ALLOW, decide("1401234567", s.copy(blockTelemarketers = false)))
        assertEquals(Verdict.ALLOW, decide("1600123456", s.copy(unknownMode = UnknownMode.BLOCK)))
        assertEquals(Verdict.ALLOW, decide("1601123456", s.copy(unknownMode = UnknownMode.BLOCK)))
    }

    @Test fun international() {
        assertEquals(Verdict.BLOCK, decide("+923001234567"))
        assertEquals(Verdict.ALLOW, decide("+971501234567"))
        assertEquals(Verdict.BLOCK, decide("+971501234567", s.copy(blockInternational = true)))
        assertEquals(Verdict.BLOCK, decide("+37120000000", s.copy(riskyCountryCodes = listOf("92", "371"))))
    }

    @Test fun hiddenAndSpoofed() {
        assertEquals(Verdict.BLOCK, decide(null, hidden = true))
        assertEquals(Verdict.ALLOW, decide(null, s.copy(blockHidden = false), hidden = true))
        assertEquals(Verdict.BLOCK, decide("9876543210", spoofed = true))
    }

    @Test fun unknownModesAndRepeatCallers() {
        val silence = s.copy(unknownMode = UnknownMode.SILENCE)
        val block = s.copy(unknownMode = UnknownMode.BLOCK)
        assertEquals(Verdict.ALLOW, decide("9876543210"))
        assertEquals(Verdict.SILENCE, decide("9876543210", silence))
        assertEquals(Verdict.BLOCK, decide("9876543210", block))
        assertEquals(Verdict.ALLOW, decide("9876543210", block, recent = 1))
        assertEquals(Verdict.BLOCK, decide("9876543210", block.copy(letRepeatCallersThrough = false), recent = 1))
    }

    @Test fun scamTextChecker() {
        val scam = "Dear customer your SBI account will be blocked today. Update KYC immediately at http://sbi-kyc.xyz/u " +
            "and share the OTP received."
        assertEquals(ScamTextChecker.Level.HIGH, ScamTextChecker.check(scam).level)
        val arrest = "This is Mumbai Police cyber cell. A parcel with drugs found in your name. Join video call statement now."
        assertEquals(ScamTextChecker.Level.HIGH, ScamTextChecker.check(arrest).level)
        assertEquals(ScamTextChecker.Level.LOW, ScamTextChecker.check("Hi, are we still meeting for lunch at 1?").level)
    }
}
