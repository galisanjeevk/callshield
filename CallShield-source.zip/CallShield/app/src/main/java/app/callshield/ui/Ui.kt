package app.callshield.ui

import android.content.Context
import android.content.res.Configuration
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.Switch
import android.widget.TextView

/** Tiny view-building helpers so the app needs zero third-party libraries. */
class Ui(private val ctx: Context) {

    val dark = (ctx.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES

    val page = if (dark) 0xFF111315.toInt() else 0xFFF7F8FA.toInt()
    val surface = if (dark) 0xFF1D2024.toInt() else 0xFFFFFFFF.toInt()
    val fg = if (dark) 0xFFE8EAED.toInt() else 0xFF1F2328.toInt()
    val sub = if (dark) 0xFFA8ADB4.toInt() else 0xFF5F6368.toInt()
    val line = if (dark) 0xFF2E3238.toInt() else 0xFFE3E5E8.toInt()
    val accent = if (dark) 0xFF7FA6FF.toInt() else 0xFF2952E3.toInt()
    val good = if (dark) 0xFF6DD58C.toInt() else 0xFF167C3A.toInt()
    val warn = if (dark) 0xFFFFB95C.toInt() else 0xFFB25E00.toInt()
    val bad = if (dark) 0xFFFF8A80.toInt() else 0xFFC5221F.toInt()

    fun dp(v: Int) = (v * ctx.resources.displayMetrics.density).toInt()

    fun column(padding: Int = 0) = LinearLayout(ctx).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(padding), dp(padding), dp(padding), dp(padding))
    }

    fun row() = LinearLayout(ctx).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
    }

    fun text(s: CharSequence, size: Float = 15f, color: Int = fg, bold: Boolean = false) = TextView(ctx).apply {
        text = s
        textSize = size
        setTextColor(color)
        if (bold) typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        setLineSpacing(0f, 1.15f)
    }

    fun title(s: String) = text(s, 13f, sub, bold = true).apply {
        isAllCaps = true
        letterSpacing = 0.06f
        setPadding(dp(4), dp(20), 0, dp(8))
    }

    fun rounded(color: Int, radius: Int = 16, stroke: Int? = null) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radius).toFloat()
        if (stroke != null) setStroke(dp(1), stroke)
    }

    fun card(vararg children: View) = column(16).apply {
        background = rounded(surface, 18, line)
        children.forEach { addView(it) }
        layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            .apply { bottomMargin = dp(10) }
    }

    fun button(label: String, filled: Boolean = true, color: Int = accent, onClick: () -> Unit) = Button(ctx).apply {
        text = label
        isAllCaps = false
        textSize = 14f
        stateListAnimator = null
        setTextColor(if (filled) (if (dark) 0xFF0B1020.toInt() else 0xFFFFFFFF.toInt()) else color)
        background = if (filled) rounded(color, 24) else rounded(0x00000000, 24, color)
        setPadding(dp(18), dp(10), dp(18), dp(10))
        minHeight = dp(44); minimumHeight = dp(44)
        setOnClickListener { onClick() }
    }

    fun chip(label: String, color: Int) = text(label, 11f, color, bold = true).apply {
        background = rounded((color and 0x00FFFFFF) or 0x22000000, 10)
        setPadding(dp(8), dp(3), dp(8), dp(3))
    }

    fun switchRow(label: String, hint: String?, checked: Boolean, onChange: (Boolean) -> Unit): View {
        val sw = Switch(ctx).apply { isChecked = checked }
        val texts = column().apply {
            addView(text(label, 15f, fg))
            if (hint != null) addView(text(hint, 13f, sub).apply { setPadding(0, dp(2), dp(8), 0) })
        }
        return row().apply {
            setPadding(0, dp(10), 0, dp(10))
            addView(texts, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            addView(sw)
            sw.setOnCheckedChangeListener { _, v -> onChange(v) }
            setOnClickListener { sw.toggle() }
        }
    }

    fun input(hint: String, value: String = "", phone: Boolean = false, multiline: Boolean = false) = EditText(ctx).apply {
        setHint(hint)
        setText(value)
        textSize = 15f
        setTextColor(fg)
        setHintTextColor(sub)
        inputType = when {
            multiline -> InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
            phone -> InputType.TYPE_CLASS_PHONE
            else -> InputType.TYPE_CLASS_TEXT
        }
        if (multiline) { minLines = 5; gravity = Gravity.TOP or Gravity.START }
        background = rounded(page, 12, line)
        setPadding(dp(14), dp(12), dp(14), dp(12))
    }

    fun spacer(h: Int) = View(ctx).apply { layoutParams = LinearLayout.LayoutParams(1, dp(h)) }

    fun divider() = View(ctx).apply {
        setBackgroundColor(line)
        layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 1)
    }

    fun wrapLp(rightMargin: Int = 8) = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
    ).apply { this.rightMargin = dp(rightMargin) }
}
